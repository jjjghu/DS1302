// pins.h

#ifndef PINS_H
#define PINS_H

extern const int CE;
extern const int IO;
extern const int SCLK;
extern const int pinA;
extern const int pinB;
extern const int pinC;
extern const int pinD;
extern const int pinE;
extern const int pinF;
extern const int pinG;
extern const int D1;
extern const int D2;
extern const int D3;
extern const int D4;

#endif // PINS_H
